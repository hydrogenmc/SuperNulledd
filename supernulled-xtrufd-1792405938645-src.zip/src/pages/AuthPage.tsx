import { useState, type FormEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Logo from '../components/Logo';
import { supabase } from '../lib/supabase';

export type AuthMode = 'login' | 'register' | 'forgot';

const TITLES: Record<AuthMode, string> = { login: 'Log in', register: 'Create your account', forgot: 'Reset your password' };

export default function AuthPage({ mode }: { mode: AuthMode }) {
    const navigate = useNavigate();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [busy, setBusy] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [notice, setNotice] = useState<string | null>(null);
    const returnUrl = window.location.origin + window.location.pathname;

    async function handleSubmit(event: FormEvent) {
        event.preventDefault();
        if (busy) return;
        setError(null);
        setNotice(null);
        if (mode !== 'forgot' && password.length < 8) {
            setError('Password must be at least 8 characters.');
            return;
        }
        setBusy(true);
        try {
            if (mode === 'login') {
                const { error: signInError } = await supabase.auth.signInWithPassword({ email, password });
                if (signInError) throw signInError;
                navigate('/');
            } else if (mode === 'register') {
                const { error: signUpError } = await supabase.auth.signUp({ email, password, options: { emailRedirectTo: returnUrl } });
                if (signUpError) throw signUpError;
                setNotice('Check your email and click the verification link to finish creating your account.');
            } else {
                const { error: resetError } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: `${returnUrl}?recovery=1` });
                if (resetError) throw resetError;
                setNotice('If that email has an account, a reset link is on its way.');
            }
        } catch (err) {
            setError(err instanceof Error ? err.message : 'Something went wrong. Please try again.');
        } finally {
            setBusy(false);
        }
    }

    async function handleGoogle() {
        if (busy) return;
        setError(null);
        setBusy(true);
        const { error: oauthError } = await supabase.auth.signInWithOAuth({ provider: 'google', options: { redirectTo: returnUrl } });
        if (oauthError) {
            setError(`Google sign-in is not available yet: ${oauthError.message}`);
            setBusy(false);
        }
    }

    return (
        <div className="mx-auto max-w-md px-4 py-12">
            <div className="mb-6 flex justify-center"><Logo large /></div>
            <form onSubmit={handleSubmit} className="card space-y-4 p-6" noValidate>
                <h1 className="text-xl font-bold">{TITLES[mode]}</h1>
                {mode !== 'forgot' && (
                    <>
                        <button type="button" className="btn-ghost w-full" onClick={handleGoogle} disabled={busy}>Continue with Google</button>
                        <p className="text-center text-xs text-zinc-500">or use email</p>
                    </>
                )}
                <label className="block text-sm">Email
                    <input className="input mt-1" type="email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
                </label>
                {mode !== 'forgot' && (
                    <label className="block text-sm">Password
                        <input className="input mt-1" type="password" autoComplete={mode === 'login' ? 'current-password' : 'new-password'} required value={password} onChange={(e) => setPassword(e.target.value)} />
                    </label>
                )}
                {error && <p role="alert" className="text-sm text-red-400">{error}</p>}
                {notice && <p role="status" className="text-sm text-[#C4B5FD]">{notice}</p>}
                <button type="submit" className="btn-primary w-full" disabled={busy}>{busy ? 'Please wait…' : TITLES[mode]}</button>
                <div className="flex justify-between text-sm text-zinc-400">
                    {mode === 'login' ? <Link to="/register" className="hover:text-[#C4B5FD]">Create account</Link> : <Link to="/login" className="hover:text-[#C4B5FD]">Back to log in</Link>}
                    {mode !== 'forgot' && <Link to="/forgot-password" className="hover:text-[#C4B5FD]">Forgot password?</Link>}
                </div>
            </form>
        </div>
    );
}
