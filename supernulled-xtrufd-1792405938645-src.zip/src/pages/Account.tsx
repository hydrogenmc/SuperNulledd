import { useEffect, useState, type FormEvent } from 'react';
import { Link, Navigate } from 'react-router-dom';
import { useAuth } from '../lib/auth';
import { supabase } from '../lib/supabase';

type MembershipRole = 'basic' | 'vip';

interface PublicPlan {
    basic_daily_free_download_limit?: number;
    vip_price_php?: number;
    perks?: Record<string, boolean>;
}

function manilaDayStart(): string {
    const date = new Intl.DateTimeFormat('en-CA', {
        timeZone: 'Asia/Manila',
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
    }).format(new Date());
    return new Date(date + 'T00:00:00+08:00').toISOString();
}

export default function Account() {
    const { session, loading, isAdmin } = useAuth();
    const userId = session?.user.id;
    const [displayName, setDisplayName] = useState('');
    const [membershipRole, setMembershipRole] = useState<MembershipRole>('basic');
    const [vipExpiresAt, setVipExpiresAt] = useState<string | null>(null);
    const [freeDownloadsUsed, setFreeDownloadsUsed] = useState(0);
    const [plan, setPlan] = useState<PublicPlan>({ basic_daily_free_download_limit: 3, vip_price_php: 199, perks: { vip_badge: true, early_access: true, exclusive_resources: true, priority_support: false } });
    const [busy, setBusy] = useState(false);
    const [message, setMessage] = useState<{ text: string; ok: boolean } | null>(null);

    useEffect(() => {
        if (!userId) return;
        let active = true;
        async function loadAccount() {
            const [profileResult, membershipResult, planResult, downloadsResult] = await Promise.all([
                supabase.from('profiles').select('display_name').eq('id', userId).maybeSingle(),
                supabase.from('user_memberships').select('role,vip_expires_at').eq('user_id', userId).maybeSingle(),
                supabase.from('site_settings').select('value').eq('key', 'public.membership').maybeSingle(),
                supabase.from('downloads').select('resource_id').eq('user_id', userId).gte('downloaded_at', manilaDayStart()),
            ]);
            if (!active) return;
            setDisplayName(profileResult.data?.display_name ?? '');
            const membership = membershipResult.data;
            const isVipActive = membership?.role === 'vip' && (!membership.vip_expires_at || Date.parse(membership.vip_expires_at) > Date.now());
            setMembershipRole(isVipActive ? 'vip' : 'basic');
            setVipExpiresAt(isVipActive ? membership?.vip_expires_at ?? null : null);
            if (planResult.data?.value && typeof planResult.data.value === 'object') {
                setPlan(planResult.data.value as PublicPlan);
            }
            const resourceIds = [...new Set((downloadsResult.data ?? []).map((row) => row.resource_id as string))];
            if (resourceIds.length > 0) {
                const { data: freeResources } = await supabase.from('resources').select('id').in('id', resourceIds).eq('price', 0);
                if (active) setFreeDownloadsUsed(freeResources?.length ?? 0);
            } else {
                setFreeDownloadsUsed(0);
            }
        }
        void loadAccount();
        return () => { active = false; };
    }, [userId]);

    if (loading) return <p className="p-8 text-center text-zinc-400">Loading…</p>;
    if (!session) return <Navigate to="/login" replace />;

    async function handleSave(event: FormEvent) {
        event.preventDefault();
        if (busy || !userId) return;
        setBusy(true);
        setMessage(null);
        const { error } = await supabase.from('profiles').update({ display_name: displayName.trim(), updated_at: new Date().toISOString() }).eq('id', userId);
        setMessage(error ? { text: 'Could not save your profile.', ok: false } : { text: 'Profile saved.', ok: true });
        setBusy(false);
    }

    const dailyLimit = Number.isInteger(plan.basic_daily_free_download_limit) && Number(plan.basic_daily_free_download_limit) > 0
        ? Number(plan.basic_daily_free_download_limit)
        : 3;
    const vipPrice = Number.isFinite(Number(plan.vip_price_php)) && Number(plan.vip_price_php) > 0
        ? Number(plan.vip_price_php)
        : 199;
    const perkNames: Record<string, string> = {
        vip_badge: 'VIP profile badge',
        early_access: 'Early access',
        exclusive_resources: 'Exclusive resources',
        priority_support: 'Priority support',
    };
    const activePerks = Object.entries(plan.perks ?? {}).filter(([, enabled]) => enabled).map(([key]) => perkNames[key] ?? key.replace(/_/g, ' '));

    return (
        <div className="mx-auto max-w-2xl space-y-5 px-4 py-10">
            <h1 className="mb-2 text-3xl font-bold">Your account</h1>
            <div className="grid grid-cols-3 gap-2 text-center text-sm">
                <Link to="/library" className="btn-ghost">My Library</Link>
                <Link to="/favorites" className="btn-ghost">Favorites</Link>
                <Link to="/orders" className="btn-ghost">Orders</Link>
            </div>

            <section className="card space-y-4 p-5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                    <h2 className="text-xl font-bold">Membership</h2>
                    <span className="badge">{membershipRole === 'vip' ? 'VIP Member' : 'Basic Member'}{isAdmin ? ' · Administrator' : ''}</span>
                </div>
                {membershipRole === 'vip' ? (
                    <div>
                        <p className="text-sm text-zinc-300">You have unlimited free downloads.</p>
                        {vipExpiresAt && <p className="mt-1 text-xs text-zinc-500">VIP expires {new Date(vipExpiresAt).toLocaleString()}</p>}
                    </div>
                ) : (
                    <div>
                        <p className="text-sm text-zinc-300">Free downloads used today: <strong>{freeDownloadsUsed} / {dailyLimit}</strong></p>
                        <p className="mt-1 text-sm text-zinc-400">VIP costs ₱{vipPrice.toLocaleString('en-PH')} and removes the daily limit for free resources.</p>
                    </div>
                )}
                {activePerks.length > 0 && (
                    <div>
                        <h3 className="text-sm font-semibold">Configured VIP perks</h3>
                        <ul className="mt-2 flex flex-wrap gap-2">{activePerks.map((perk) => <li key={perk} className="badge">{perk}</li>)}</ul>
                    </div>
                )}
                <p className="text-xs text-zinc-500">VIP does not automatically grant ownership of paid resources. Stripe checkout is not connected yet, so you cannot purchase VIP from this page yet.</p>
            </section>

            <form onSubmit={handleSave} className="card space-y-4 p-6">
                <p className="text-sm text-zinc-400">Signed in as {session.user.email} {isAdmin && <span className="badge ml-1">Administrator</span>}</p>
                <label className="block text-sm">Display name
                    <input className="input mt-1" maxLength={60} value={displayName} onChange={(event) => setDisplayName(event.target.value)} />
                </label>
                {message && <p role={message.ok ? 'status' : 'alert'} className={message.ok ? 'text-[#C4B5FD]' : 'text-red-400'}>{message.text}</p>}
                <button type="submit" className="btn-primary w-full" disabled={busy}>{busy ? 'Saving…' : 'Save changes'}</button>
            </form>
        </div>
    );
}
