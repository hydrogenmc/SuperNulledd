import { useEffect, useState, type FormEvent } from 'react';
import { supabase } from '../../lib/supabase';

const KEYS = { announcement: 'public.announcement', support: 'public.support_contact', maintenance: 'public.maintenance' } as const;
const MAX_TEXT_LENGTH = 300;

export default function SettingsManager() {
    const [announcement, setAnnouncement] = useState('');
    const [supportContact, setSupportContact] = useState('');
    const [maintenance, setMaintenance] = useState(false);
    const [busy, setBusy] = useState(false);
    const [message, setMessage] = useState<{ text: string; ok: boolean } | null>(null);

    useEffect(() => {
        supabase.from('site_settings').select('key,value').like('key', 'public.%').then(({ data }) => {
            const values = Object.fromEntries((data ?? []).map((row) => [row.key as string, row.value as unknown]));
            setAnnouncement(typeof values[KEYS.announcement] === 'string' ? (values[KEYS.announcement] as string) : '');
            setSupportContact(typeof values[KEYS.support] === 'string' ? (values[KEYS.support] as string) : '');
            setMaintenance(values[KEYS.maintenance] === true);
        });
    }, []);

    async function handleSave(event: FormEvent) {
        event.preventDefault();
        if (busy) return;
        if (announcement.length > MAX_TEXT_LENGTH || supportContact.length > MAX_TEXT_LENGTH) {
            setMessage({ text: `Keep each text under ${MAX_TEXT_LENGTH} characters.`, ok: false });
            return;
        }
        setBusy(true);
        const now = new Date().toISOString();
        const { error } = await supabase.from('site_settings').upsert([
            { key: KEYS.announcement, value: announcement.trim(), updated_at: now },
            { key: KEYS.support, value: supportContact.trim(), updated_at: now },
            { key: KEYS.maintenance, value: maintenance, updated_at: now },
        ]);
        setMessage(error ? { text: 'Could not save settings.', ok: false } : { text: 'Settings saved.', ok: true });
        setBusy(false);
    }

    return (
        <form onSubmit={handleSave} className="card max-w-xl space-y-4 p-4">
            <label className="block text-sm">Announcement banner (leave empty to hide)
                <input className="input mt-1" maxLength={MAX_TEXT_LENGTH} value={announcement} onChange={(e) => setAnnouncement(e.target.value)} />
            </label>
            <label className="block text-sm">Support contact (shown on the Support page)
                <input className="input mt-1" maxLength={MAX_TEXT_LENGTH} value={supportContact} onChange={(e) => setSupportContact(e.target.value)} />
            </label>
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={maintenance} onChange={(e) => setMaintenance(e.target.checked)} /> Maintenance mode (visitors see a notice; you can still log in)</label>
            {message && <p role={message.ok ? 'status' : 'alert'} className={message.ok ? 'text-[#C4B5FD]' : 'text-red-400'}>{message.text}</p>}
            <button type="submit" className="btn-primary" disabled={busy}>{busy ? 'Saving…' : 'Save settings'}</button>
        </form>
    );
}
