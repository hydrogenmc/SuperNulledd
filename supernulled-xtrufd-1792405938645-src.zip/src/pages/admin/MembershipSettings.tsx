import { useEffect, useState, type FormEvent } from 'react';
import { supabase } from '../../lib/supabase';

type Perks = {
    vip_badge: boolean;
    early_access: boolean;
    exclusive_resources: boolean;
    priority_support: boolean;
};

type StripeSettings = {
    enabled: boolean;
    mode: 'test' | 'live';
    publishable_key: string;
    price_id: string;
};

const DEFAULT_PERKS: Perks = {
    vip_badge: true,
    early_access: true,
    exclusive_resources: true,
    priority_support: false,
};

const DEFAULT_STRIPE: StripeSettings = {
    enabled: false,
    mode: 'test',
    publishable_key: '',
    price_id: '',
};

const PERK_LABELS: { key: keyof Perks; label: string; description: string }[] = [
    { key: 'vip_badge', label: 'VIP profile badge', description: 'Show a VIP badge beside the member name.' },
    { key: 'early_access', label: 'Early access', description: 'Configure early-access perks for future releases.' },
    { key: 'exclusive_resources', label: 'Exclusive resources', description: 'Configure VIP-only resource access.' },
    { key: 'priority_support', label: 'Priority support', description: 'Offer priority support to VIP members.' },
];

function asRecord(value: unknown): Record<string, unknown> {
    return value && typeof value === 'object' && !Array.isArray(value)
        ? value as Record<string, unknown>
        : {};
}

export default function MembershipSettings() {
    const [basicLimit, setBasicLimit] = useState(3);
    const [vipPrice, setVipPrice] = useState('199');
    const [perks, setPerks] = useState<Perks>(DEFAULT_PERKS);
    const [stripe, setStripe] = useState<StripeSettings>(DEFAULT_STRIPE);
    const [loading, setLoading] = useState(true);
    const [busy, setBusy] = useState(false);
    const [message, setMessage] = useState<{ text: string; ok: boolean } | null>(null);

    useEffect(() => {
        async function load() {
            const { data, error } = await supabase
                .from('site_settings')
                .select('key,value')
                .in('key', ['membership.config']);
            if (error) {
                setMessage({ text: 'Could not load membership settings. Check the site_settings table permissions.', ok: false });
                setLoading(false);
                return;
            }

            const row = data?.find((item) => item.key === 'membership.config');
            const config = asRecord(row?.value);
            const savedPerks = asRecord(config.perks);
            const savedStripe = asRecord(config.stripe);
            const limit = Number(config.basic_daily_free_download_limit ?? 3);
            const price = Number(config.vip_price_php ?? 199);

            setBasicLimit(Number.isInteger(limit) && limit >= 1 && limit <= 1000 ? limit : 3);
            setVipPrice(String(Number.isFinite(price) && price > 0 ? price : 199));
            setPerks({
                vip_badge: typeof savedPerks.vip_badge === 'boolean' ? savedPerks.vip_badge : DEFAULT_PERKS.vip_badge,
                early_access: typeof savedPerks.early_access === 'boolean' ? savedPerks.early_access : DEFAULT_PERKS.early_access,
                exclusive_resources: typeof savedPerks.exclusive_resources === 'boolean' ? savedPerks.exclusive_resources : DEFAULT_PERKS.exclusive_resources,
                priority_support: typeof savedPerks.priority_support === 'boolean' ? savedPerks.priority_support : DEFAULT_PERKS.priority_support,
            });
            setStripe({
                enabled: savedStripe.enabled === true,
                mode: savedStripe.mode === 'live' ? 'live' : 'test',
                publishable_key: typeof savedStripe.publishable_key === 'string' ? savedStripe.publishable_key : '',
                price_id: typeof savedStripe.price_id === 'string' ? savedStripe.price_id : '',
            });
            setLoading(false);
        }
        void load();
    }, []);

    function updateStripe<K extends keyof StripeSettings>(key: K, value: StripeSettings[K]) {
        setStripe((current) => ({ ...current, [key]: value }));
    }

    async function handleSave(event: FormEvent) {
        event.preventDefault();
        if (busy) return;

        const price = Number(vipPrice);
        if (!Number.isInteger(basicLimit) || basicLimit < 1 || basicLimit > 1000) {
            setMessage({ text: 'The daily free-download limit must be between 1 and 1000.', ok: false });
            return;
        }
        if (!Number.isFinite(price) || price <= 0 || price > 100000) {
            setMessage({ text: 'Enter a valid VIP price between ₱1 and ₱100,000.', ok: false });
            return;
        }
        if (stripe.publishable_key && !stripe.publishable_key.startsWith('pk_')) {
            setMessage({ text: 'Stripe publishable keys should start with pk_test_ or pk_live_.', ok: false });
            return;
        }
        if (stripe.price_id && !stripe.price_id.startsWith('price_')) {
            setMessage({ text: 'Stripe Price ID should start with price_.', ok: false });
            return;
        }
        if (stripe.enabled && (!stripe.publishable_key || !stripe.price_id)) {
            setMessage({ text: 'Add the Stripe publishable key and Price ID before marking Stripe setup enabled.', ok: false });
            return;
        }

        setBusy(true);
        setMessage(null);
        const now = new Date().toISOString();
        const config = {
            basic_daily_free_download_limit: basicLimit,
            vip_price_php: price,
            perks,
            stripe,
        };
        const publicPlan = {
            basic_daily_free_download_limit: basicLimit,
            vip_price_php: price,
            perks,
        };
        const { error } = await supabase.from('site_settings').upsert([
            { key: 'membership.config', value: config, updated_at: now },
            { key: 'public.membership', value: publicPlan, updated_at: now },
        ]);
        setMessage(error
            ? { text: 'Could not save membership settings. Verify the admin database permissions and try again.', ok: false }
            : { text: 'Membership and Stripe setup settings saved.', ok: true });
        setBusy(false);
    }

    if (loading) return <p className="text-sm text-zinc-400">Loading membership settings…</p>;

    return (
        <form onSubmit={handleSave} className="space-y-5">
            <section className="card max-w-3xl space-y-4 p-5">
                <div>
                    <h2 className="text-xl font-bold">Membership plans</h2>
                    <p className="mt-1 text-sm text-zinc-400">These settings are saved to Supabase and used by the secure download service.</p>
                </div>
                <div className="grid gap-4 sm:grid-cols-2">
                    <label className="block text-sm">Basic Member free downloads per day
                        <input className="input mt-1" type="number" min={1} max={1000} step={1} value={basicLimit} onChange={(event) => setBasicLimit(Number(event.target.value))} required />
                    </label>
                    <label className="block text-sm">VIP price (PHP)
                        <div className="mt-1 flex items-center gap-2"><span className="text-zinc-400">₱</span><input className="input" type="number" min={1} max={100000} step="1" value={vipPrice} onChange={(event) => setVipPrice(event.target.value)} required /></div>
                    </label>
                </div>
                <div className="rounded-xl border border-[#2a2145] p-4">
                    <h3 className="font-semibold">VIP plan perks</h3>
                    <div className="mt-3 space-y-3">
                        {PERK_LABELS.map((perk) => (
                            <label key={perk.key} className="flex items-start gap-3 text-sm">
                                <input className="mt-1" type="checkbox" checked={perks[perk.key]} onChange={(event) => setPerks((current) => ({ ...current, [perk.key]: event.target.checked }))} />
                                <span><span className="font-medium">{perk.label}</span><span className="mt-0.5 block text-xs text-zinc-400">{perk.description}</span></span>
                            </label>
                        ))}
                    </div>
                    <p className="mt-3 text-xs text-zinc-500">Unlimited free downloads and the VIP badge are active. Early-access, exclusive-resource, and priority-support switches save your plan configuration; connect them to those features before advertising them as available.</p>
                </div>
            </section>

            <section className="card max-w-3xl space-y-4 p-5">
                <div>
                    <h2 className="text-xl font-bold">Stripe VIP checkout setup</h2>
                    <p className="mt-1 text-sm text-zinc-400">Enter the non-secret Stripe details now, or leave them blank and finish setup later.</p>
                </div>
                <label className="block text-sm">Stripe mode
                    <select className="input mt-1" value={stripe.mode} onChange={(event) => updateStripe('mode', event.target.value === 'live' ? 'live' : 'test')}>
                        <option value="test">Test mode</option>
                        <option value="live">Live mode</option>
                    </select>
                </label>
                <label className="block text-sm">Stripe publishable key
                    <input className="input mt-1" autoComplete="off" placeholder={stripe.mode === 'test' ? 'pk_test_…' : 'pk_live_…'} value={stripe.publishable_key} onChange={(event) => updateStripe('publishable_key', event.target.value.trim())} />
                </label>
                <label className="block text-sm">Stripe Price ID for the VIP plan
                    <input className="input mt-1" autoComplete="off" placeholder="price_…" value={stripe.price_id} onChange={(event) => updateStripe('price_id', event.target.value.trim())} />
                </label>
                <label className="flex items-start gap-3 text-sm">
                    <input className="mt-1" type="checkbox" checked={stripe.enabled} onChange={(event) => updateStripe('enabled', event.target.checked)} />
                    <span><span className="font-medium">Mark Stripe setup as enabled</span><span className="mt-0.5 block text-xs text-zinc-400">This saves your preference only. It does not activate checkout until the server-side Stripe Checkout endpoint and signed webhook are deployed.</span></span>
                </label>
                <div className="rounded-lg border border-amber-500/30 bg-amber-500/5 p-3 text-sm text-amber-200">
                    Never put a Stripe secret key or webhook signing secret in this form. When you are ready, add them as Supabase Edge Function secrets and deploy the Stripe checkout and webhook handlers. Stripe payments are not active yet.
                </div>
            </section>

            {message && <p role={message.ok ? 'status' : 'alert'} className={message.ok ? 'text-[#C4B5FD]' : 'text-red-400'}>{message.text}</p>}
            <button type="submit" className="btn-primary" disabled={busy}>{busy ? 'Saving…' : 'Save membership setup'}</button>
        </form>
    );
}
